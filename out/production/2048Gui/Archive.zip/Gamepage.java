import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.paint.Color;

import java.awt.*;

/**
 * Created by zhonge on 3/4/17.
 */
public class Gamepage extends Application{


    @Override
    public void start(Stage primaryStage){
        BorderPane root = new BorderPane();

        root.setCenter(addBoardPane());
        root.setTop(addTopPane());

        Scene scene = new Scene(root,1200,800);
        scene.getStylesheets().add
                (WelcomePage.class.getResource("Gamepage.css").toExternalForm());
        primaryStage.setTitle("GAME 2048");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public Node addBoardPane() {
        StackPane board = new StackPane();


        Rectangle rec = new Rectangle();

        rec.setWidth(500);
        rec.setHeight(520);
        board.getChildren().add(rec);

        rec.setFill(Color.rgb(52,30,105,0.4));
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);


        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10,10,10,10));

        int rowNum = 24;
        int colNum = 4;
        for (int row = 20; row < rowNum; row++) {
            for (int col=0; col < colNum; col++) {
                Rectangle newtile = new Rectangle();

                newtile.setFill(Color.rgb(180,130,180,0.2));

                newtile.setWidth(110);
                newtile.setHeight(110);
                newtile.setX(50);
                newtile.setY(50);
                grid.add(newtile, col, row);
            }


            grid.setGridLinesVisible(true);

        }

        board.getChildren().add(grid);
        board.setAlignment(Pos.BOTTOM_CENTER);
        board.setPadding(new Insets(10,10,80,10));

        return board;

    }


    public Node addTopPane() {

        GridPane topPane = new GridPane();
        topPane.setAlignment(Pos.TOP_LEFT);
        topPane.setPadding(new Insets(100,10,10,10));

        topPane.setHgap(10);
        topPane.setVgap(10);
        topPane.add(addTitle(), 35, 0);


        return topPane;

    }

    private Node addTitle() {

            StackPane titlePane = new StackPane();
            titlePane.setAlignment(Pos.CENTER);

            Rectangle rec = new Rectangle(220,100,Color.YELLOW);
            Text gametitle = new Text("2048");

            titlePane.getChildren().add(rec);
            titlePane.getChildren().add(gametitle);



        return titlePane;

    }



}
